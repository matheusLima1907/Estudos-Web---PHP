<?php 

header ("location: http://localhost/tattoo/login.html"); ?>


