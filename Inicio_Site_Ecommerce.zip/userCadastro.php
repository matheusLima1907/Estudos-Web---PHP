<!DOCTYPE html>
<html>

    <head>
        <title>
            Cadastro de Usuario
        </title> 
        <meta charset="utf-8">
    </head>

    <body>

        <div id="top" class="top">
            <H1>
                
            </H1>
        </div>

        <div id="content" class="content">

            <!-- Div contendo form de login na aplicação -->
            <div id="divUserCdt" class="divUserCdt"> 
                <form action="" method="POST" id="formCdt" class="formCdt">
                    <label for="cdtname"> Primeiro Nome: </label><br>
                    <input type="text" id="cdtname" name="cdtname"><br>
                   
                    <label for="lgnsenha"> Ultimo Nome: </label><br>
                    <input type="text" id="cdtLast" name="cdtLast"><br>
                   
                    <label for="userMail"> Email: </label><br>
                    <input type="email" id="userMail" name="userMail"><br>
                   
                    <label for="userMail"> Senha: </label><br>
                    <input type="password" id="userPswd" name="userPswd"><br><br>
                   
                    <input type="submit" id="btnCdt" value="Cadastrar"><br><br>
                    
                </form>               
            </div>

        </div>

        <div id="footer" class="footer">

        </div>        



    </body>