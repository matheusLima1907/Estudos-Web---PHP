<?php

//variáveis adquiridas da tela de login
$id = $_POST['lgnname'];
$senha = $_POST['lgnsenha'];

//variáveis estáticas para validação
$verificaId = "testeId";
$verificaSenha = "testeSenha";

    //verifica se as variáveis adquiridas são iguais às estáticas
    if($id == $verificaId && $senha == $verificaSenha){
        echo("Login Efetuado Com Sucesso");       
    }
    else
        echo("Login e/ou Senha Incorretos");

?>