<!DOCTYPE html>
<html>

    <head>
        <title>
            Studio 23 Tattoo Shop
        </title> 
        <meta charset="utf-8">
    </head>

    <body>

        <div id="top" class="top">
            <H1>
                Aqui haverá um menu horizontal para navegar entre as telas do site!
            </H1>
        </div>

        <div id="content" class="content">

            <!-- Div contendo form de login na aplicação -->
            <div id="divlgn" class="divlgn"> 
                <form action="login_action.php" method="POST" id="formlgn" class="formlgn">
                    <label for="lgnname"> Login: </label><br>
                    <input type="text" id="lgnname" name="lgnname"><br>
                    <label for="lgnsenha"> Senha: </label><br>
                    <input type="password" id="lgnsenha" name="lgnsenha"><br><br>
                    <input type="submit" id="btnlgn" value="Entrar"><br><br>
                    <a href="/redefinirsenha.php">Esqueci minha senha</a><br><br>
                </form>               
            </div>

        </div>

        <div id="footer" class="footer">

        <!-- Cadastro de usuários sem login -->
        <div id="CadastroUsuario" class="CadastroUsuario">
            <form action="userCadastro.php" method="POST" id="formCdt" class="formCdt">
                <label for="btnCadastro"> Não possui cadastro? </label><br><br>
                <input type="submit" id="btnUserCadastro" value="Cadastrar">
            </form>
        </div>

        </div>        



    </body>




</html>